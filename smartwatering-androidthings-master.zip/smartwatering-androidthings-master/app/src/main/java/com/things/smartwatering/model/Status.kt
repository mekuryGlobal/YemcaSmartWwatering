package com.things.smartwatering.model

data class Status(val waterStatus: Boolean = false,
                  val autoStatus: Boolean = false)